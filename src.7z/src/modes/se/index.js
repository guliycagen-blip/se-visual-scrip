// src/modes/se/index.js

// --- ШАГ 1: ВСЕ ИМПОРТЫ В САМОМ ВЕРХУ ---
// Это исправляет ошибку ESLint

import * as Blockly from 'blockly/core';

// СНАЧАЛА импортируем главный файл генератора, чтобы создать объект Blockly.CSharp
import '../../generator/csharp.js'; 

// ЗАТЕМ импортируем файлы, которые добавляют к нему определения блоков
import '../standard_csharp_generator.js'; 
import './se_blocks.js';

// Импортируем остальные части конфигурации
import { toolbox } from './toolbox.js';
import { SeTheme } from '../../theme/se_theme.js';

// --- ШАГ 2: СОЗДАНИЕ И ЭКСПОРТ КОНФИГУРАЦИИ ---

// Получаем уже созданный и дополненный генератор
const generator = Blockly.CSharp;

// Экспортируем чистый объект config без циклических ссылок
export const config = {
  toolbox: toolbox, 
  theme: SeTheme,
  renderer: 'thrasos',
  workspaceOptions: {},
  generator: generator,
};