// src/modes/se/se_blocks.js

import * as Blockly from 'blockly/core';

// --- EVENT BLOCKS ---

Blockly.Blocks['event_whenflagclicked'] = {
  init: function() {
    this.jsonInit({
      "id": "event_whenflagclicked",
      "message0": "when green flag clicked",
      "nextStatement": null,
      "style": "variable_category", // ИСПРАВЛЕНО
      "tooltip": "Triggers when the green flag is clicked."
    });
  }
};

// --- CONTROL BLOCKS ---

Blockly.Blocks['control_wait'] = {
    init: function() {
      this.jsonInit({
        "id": "control_wait",
        "message0": "wait %1 seconds",
        "args0": [
          { "type": "input_value", "name": "DURATION" }
        ],
        "previousStatement": null,
        "nextStatement": null,
        "style": "loop_category" // ИСПРАВЛЕНО
      });
    }
};

// ... и так далее для всех остальных блоков ...
// Я проделаю это для вас ниже.

// --- Полный исправленный файл se_blocks.js ---

// Просто скопируйте и вставьте всё, что ниже, в ваш файл.

Blockly.Blocks['control_repeat'] = {
    init: function() { this.jsonInit({ "id": "control_repeat", "message0": "repeat %1", "message1": "%1", "args0": [{ "type": "input_value", "name": "TIMES" }], "args1": [{ "type": "input_statement", "name": "SUBSTACK" }], "previousStatement": null, "nextStatement": null, "style": "loop_category" }); }
};
Blockly.Blocks['control_forever'] = {
    init: function() { this.jsonInit({ "id": "control_forever", "message0": "forever", "message1": "%1", "args1": [{ "type": "input_statement", "name": "SUBSTACK" }], "previousStatement": null, "nextStatement": null, "style": "loop_category" }); }
};
Blockly.Blocks['control_if'] = {
    init: function() { this.jsonInit({ "type": "control_if", "message0": "if %1 then", "message1": "%1", "args0": [{"type": "input_value", "name": "CONDITION", "check": "Boolean"}], "args1": [{"type": "input_statement", "name": "SUBSTACK"}], "previousStatement": null, "nextStatement": null, "style": "loop_category" }); }
};
Blockly.Blocks['control_if_else'] = {
    init: function() { this.jsonInit({ "type": "control_if_else", "message0": "if %1 then", "message1": "%1", "message2": "else", "message3": "%1", "args0": [{"type": "input_value", "name": "CONDITION", "check": "Boolean"}], "args1": [{"type": "input_statement", "name": "SUBSTACK"}], "args3": [{"type": "input_statement", "name": "SUBSTACK2"}], "previousStatement": null, "nextStatement": null, "style": "loop_category" }); }
};
Blockly.Blocks['control_wait_until'] = {
    init: function() { this.jsonInit({ "message0": "wait until %1", "args0": [{"type": "input_value", "name": "CONDITION", "check": "Boolean"}], "previousStatement": null, "nextStatement": null, "style": "loop_category" }); }
};
Blockly.Blocks['control_repeat_until'] = {
    init: function() { this.jsonInit({ "message0": "repeat until %1", "message1": "%1", "args0": [{"type": "input_value", "name": "CONDITION", "check": "Boolean"}], "args1": [{"type": "input_statement", "name": "SUBSTACK"}], "previousStatement": null, "nextStatement": null, "style": "loop_category" }); }
};
Blockly.Blocks['control_stop'] = {
    init: function() { this.jsonInit({ "message0": "stop %1", "args0": [{"type": "field_dropdown", "name": "STOP_OPTION", "options": [["all", "all"], ["this script", "this script"], ["other scripts in sprite", "other scripts in sprite"]]}], "previousStatement": null, "style": "loop_category" }); }
};

// --- OPERATOR BLOCKS ---
Blockly.Blocks['operator_add'] = { init: function() { this.jsonInit({ "message0": "%1 + %2", "args0": [{"type": "input_value", "name": "NUM1"}, {"type": "input_value", "name": "NUM2"}], "output": "Number", "style": "math_category" }); } };
Blockly.Blocks['operator_subtract'] = { init: function() { this.jsonInit({ "message0": "%1 - %2", "args0": [{"type": "input_value", "name": "NUM1"}, {"type": "input_value", "name": "NUM2"}], "output": "Number", "style": "math_category" }); } };
Blockly.Blocks['operator_multiply'] = { init: function() { this.jsonInit({ "message0": "%1 * %2", "args0": [{"type": "input_value", "name": "NUM1"}, {"type": "input_value", "name": "NUM2"}], "output": "Number", "style": "math_category" }); } };
Blockly.Blocks['operator_divide'] = { init: function() { this.jsonInit({ "message0": "%1 / %2", "args0": [{"type": "input_value", "name": "NUM1"}, {"type": "input_value", "name": "NUM2"}], "output": "Number", "style": "math_category" }); } };
Blockly.Blocks['operator_random'] = { init: function() { this.jsonInit({ "message0": "pick random %1 to %2", "args0": [{"type": "input_value", "name": "FROM"}, {"type": "input_value", "name": "TO"}], "output": "Number", "style": "math_category" }); } };
Blockly.Blocks['operator_lt'] = { init: function() { this.jsonInit({ "message0": "%1 < %2", "args0": [{"type": "input_value", "name": "OPERAND1"}, {"type": "input_value", "name": "OPERAND2"}], "output": "Boolean", "style": "math_category" }); } };
Blockly.Blocks['operator_equals'] = { init: function() { this.jsonInit({ "message0": "%1 = %2", "args0": [{"type": "input_value", "name": "OPERAND1"}, {"type": "input_value", "name": "OPERAND2"}], "output": "Boolean", "style": "math_category" }); } };
Blockly.Blocks['operator_gt'] = { init: function() { this.jsonInit({ "message0": "%1 > %2", "args0": [{"type": "input_value", "name": "OPERAND1"}, {"type": "input_value", "name": "OPERAND2"}], "output": "Boolean", "style": "math_category" }); } };
Blockly.Blocks['operator_and'] = { init: function() { this.jsonInit({ "message0": "%1 and %2", "args0": [{"type": "input_value", "name": "OPERAND1", "check": "Boolean"}, {"type": "input_value", "name": "OPERAND2", "check": "Boolean"}], "output": "Boolean", "style": "math_category" }); } };
Blockly.Blocks['operator_or'] = { init: function() { this.jsonInit({ "message0": "%1 or %2", "args0": [{"type": "input_value", "name": "OPERAND1", "check": "Boolean"}, {"type": "input_value", "name": "OPERAND2", "check": "Boolean"}], "output": "Boolean", "style": "math_category" }); } };
Blockly.Blocks['operator_not'] = { init: function() { this.jsonInit({ "message0": "not %1", "args0": [{"type": "input_value", "name": "OPERAND", "check": "Boolean"}], "output": "Boolean", "style": "math_category" }); } };
Blockly.Blocks['operator_join'] = { init: function() { this.jsonInit({ "message0": "join %1 %2", "args0": [{"type": "input_value", "name": "STRING1"}, {"type": "input_value", "name": "STRING2"}], "output": "String", "style": "text_category" }); } };
Blockly.Blocks['operator_letter_of'] = { init: function() { this.jsonInit({ "message0": "letter %1 of %2", "args0": [{"type": "input_value", "name": "LETTER"}, {"type": "input_value", "name": "STRING"}], "output": "String", "style": "text_category" }); } };
Blockly.Blocks['operator_length'] = { init: function() { this.jsonInit({ "message0": "length of %1", "args0": [{"type": "input_value", "name": "STRING"}], "output": "Number", "style": "text_category" }); } };
Blockly.Blocks['operator_contains'] = { init: function() { this.jsonInit({ "message0": "%1 contains %2?", "args0": [{"type": "input_value", "name": "STRING1"}, {"type": "input_value", "name": "STRING2"}], "output": "Boolean", "style": "text_category" }); } };
Blockly.Blocks['operator_mod'] = { init: function() { this.jsonInit({ "message0": "%1 mod %2", "args0": [{"type": "input_value", "name": "NUM1"}, {"type": "input_value", "name": "NUM2"}], "output": "Number", "style": "math_category" }); } };
Blockly.Blocks['operator_round'] = { init: function() { this.jsonInit({ "message0": "round %1", "args0": [{"type": "input_value", "name": "NUM"}], "output": "Number", "style": "math_category" }); } };
Blockly.Blocks['operator_mathop'] = { init: function() { this.jsonInit({ "message0": "%1 of %2", "args0": [{"type": "field_dropdown", "name": "OPERATOR", "options": [["abs", "abs"], ["floor", "floor"], ["ceiling", "ceiling"], ["sqrt", "sqrt"], ["sin", "sin"], ["cos", "cos"], ["tan", "tan"], ["asin", "asin"], ["acos", "acos"], ["atan", "atan"], ["ln", "ln"], ["log", "log"], ["e ^", "e ^"], ["10 ^", "10 ^"]]}, {"type": "input_value", "name": "NUM"}], "output": "Number", "style": "math_category" }); } };

// --- SENSING BLOCKS ---
Blockly.Blocks['sensing_touchingobject'] = { init: function() { this.jsonInit({ "message0": "touching %1?", "args0": [{"type": "input_value", "name": "OBJECT"}], "output": "Boolean", "style": "logic_category" }); } };
Blockly.Blocks['sensing_touchingcolor'] = { init: function() { this.jsonInit({ "message0": "touching color %1?", "args0": [{"type": "input_value", "name": "COLOR"}], "output": "Boolean", "style": "logic_category" }); } };
Blockly.Blocks['sensing_coloristouchingcolor'] = { init: function() { this.jsonInit({ "message0": "color %1 is touching %2?", "args0": [{"type": "input_value", "name": "COLOR1"}, {"type": "input_value", "name": "COLOR2"}], "output": "Boolean", "style": "logic_category" }); } };
Blockly.Blocks['sensing_distanceto'] = { init: function() { this.jsonInit({ "message0": "distance to %1", "args0": [{"type": "input_value", "name": "OBJECT"}], "output": "Number", "style": "logic_category" }); } };
Blockly.Blocks['sensing_askandwait'] = { init: function() { this.jsonInit({ "message0": "ask %1 and wait", "args0": [{"type": "input_value", "name": "QUESTION"}], "previousStatement": null, "nextStatement": null, "style": "logic_category" }); } };
Blockly.Blocks['sensing_answer'] = { init: function() { this.jsonInit({ "message0": "answer", "output": "String", "style": "logic_category" }); } };
Blockly.Blocks['sensing_keypressed'] = { init: function() { this.jsonInit({ "message0": "key %1 pressed?", "args0": [{"type": "input_value", "name": "KEY_OPTION"}], "output": "Boolean", "style": "logic_category" }); } };
Blockly.Blocks['sensing_mousedown'] = { init: function() { this.jsonInit({ "message0": "mouse down?", "output": "Boolean", "style": "logic_category" }); } };
Blockly.Blocks['sensing_mousex'] = { init: function() { this.jsonInit({ "message0": "mouse x", "output": "Number", "style": "logic_category" }); } };
Blockly.Blocks['sensing_mousey'] = { init: function() { this.jsonInit({ "message0": "mouse y", "output": "Number", "style": "logic_category" }); } };
Blockly.Blocks['sensing_setdragmode'] = { init: function() { this.jsonInit({ "message0": "set drag mode %1", "args0": [{"type": "field_dropdown", "name": "DRAG_MODE", "options": [["draggable", "draggable"], ["not draggable", "not draggable"]]}], "previousStatement": null, "nextStatement": null, "style": "logic_category" }); } };
Blockly.Blocks['sensing_loudness'] = { init: function() { this.jsonInit({ "message0": "loudness", "output": "Number", "style": "logic_category" }); } };
Blockly.Blocks['sensing_timer'] = { init: function() { this.jsonInit({ "message0": "timer", "output": "Number", "style": "logic_category" }); } };
Blockly.Blocks['sensing_resettimer'] = { init: function() { this.jsonInit({ "message0": "reset timer", "previousStatement": null, "nextStatement": null, "style": "logic_category" }); } };
Blockly.Blocks['sensing_of'] = { init: function() { this.jsonInit({ "message0": "%1 of %2", "args0": [{"type": "field_dropdown", "name": "PROPERTY", "options": [["x position", "x position"], ["y position", "y position"]]}, {"type": "input_value", "name": "OBJECT"}], "output": "Number", "style": "logic_category" }); } };
Blockly.Blocks['sensing_current'] = { init: function() { this.jsonInit({ "message0": "current %1", "args0": [{"type": "field_dropdown", "name": "CURRENTMENU", "options": [["year", "YEAR"], ["month", "MONTH"], ["date", "DATE"], ["day of week", "DAYOFWEEK"], ["hour", "HOUR"], ["minute", "MINUTE"], ["second", "SECOND"]]}], "output": "Number", "style": "logic_category" }); } };
Blockly.Blocks['sensing_dayssince2000'] = { init: function() { this.jsonInit({ "message0": "days since 2000", "output": "Number", "style": "logic_category" }); } };
Blockly.Blocks['sensing_username'] = { init: function() { this.jsonInit({ "message0": "username", "output": "String", "style": "logic_category" }); } };

// --- DATA BLOCKS ---
Blockly.Blocks['data_variable'] = { init: function() { this.jsonInit({ "message0": "%1", "args0": [{"type": "field_variable", "name": "VARIABLE", "variable": "my variable"}], "output": null, "style": "variable_category" }); } };
Blockly.Blocks['data_setvariableto'] = { init: function() { this.jsonInit({ "message0": "set %1 to %2", "args0": [{"type": "field_variable", "name": "VARIABLE", "variable": "my variable"}, {"type": "input_value", "name": "VALUE"}], "previousStatement": null, "nextStatement": null, "style": "variable_category" }); } };
Blockly.Blocks['data_changevariableby'] = { init: function() { this.jsonInit({ "message0": "change %1 by %2", "args0": [{"type": "field_variable", "name": "VARIABLE", "variable": "my variable"}, {"type": "input_value", "name": "VALUE"}], "previousStatement": null, "nextStatement": null, "style": "variable_category" }); } };
Blockly.Blocks['data_showvariable'] = { init: function() { this.jsonInit({ "message0": "show variable %1", "args0": [{"type": "field_variable", "name": "VARIABLE", "variable": "my variable"}], "previousStatement": null, "nextStatement": null, "style": "variable_category" }); } };
Blockly.Blocks['data_hidevariable'] = { init: function() { this.jsonInit({ "message0": "hide variable %1", "args0": [{"type": "field_variable", "name": "VARIABLE", "variable": "my variable"}], "previousStatement": null, "nextStatement": null, "style": "variable_category" }); } };
Blockly.Blocks['data_listcontents'] = { init: function() { this.jsonInit({ "message0": "%1", "args0": [{"type": "field_variable", "name": "LIST", "variableType": "list"}], "output": null, "style": "list_category" }); } };
Blockly.Blocks['data_addtolist'] = { init: function() { this.jsonInit({ "message0": "add %1 to %2", "args0": [{"type": "input_value", "name": "ITEM"}, {"type": "field_variable", "name": "LIST", "variableType": "list"}], "previousStatement": null, "nextStatement": null, "style": "list_category" }); } };
Blockly.Blocks['data_deleteoflist'] = { init: function() { this.jsonInit({ "message0": "delete %1 of %2", "args0": [{"type": "input_value", "name": "INDEX"}, {"type": "field_variable", "name": "LIST", "variableType": "list"}], "previousStatement": null, "nextStatement": null, "style": "list_category" }); } };
Blockly.Blocks['data_deletealloflist'] = { init: function() { this.jsonInit({ "message0": "delete all of %1", "args0": [{"type": "field_variable", "name": "LIST", "variableType": "list"}], "previousStatement": null, "nextStatement": null, "style": "list_category" }); } };
Blockly.Blocks['data_insertatlist'] = { init: function() { this.jsonInit({ "message0": "insert %1 at %2 of %3", "args0": [{"type": "input_value", "name": "ITEM"}, {"type": "input_value", "name": "INDEX"}, {"type": "field_variable", "name": "LIST", "variableType": "list"}], "previousStatement": null, "nextStatement": null, "style": "list_category" }); } };
Blockly.Blocks['data_replaceitemoflist'] = { init: function() { this.jsonInit({ "message0": "replace item %1 of %2 with %3", "args0": [{"type": "input_value", "name": "INDEX"}, {"type": "field_variable", "name": "LIST", "variableType": "list"}, {"type": "input_value", "name": "ITEM"}], "previousStatement": null, "nextStatement": null, "style": "list_category" }); } };
Blockly.Blocks['data_itemoflist'] = { init: function() { this.jsonInit({ "message0": "item %1 of %2", "args0": [{"type": "input_value", "name": "INDEX"}, {"type": "field_variable", "name": "LIST", "variableType": "list"}], "output": null, "style": "list_category" }); } };
Blockly.Blocks['data_itemnumoflist'] = { init: function() { this.jsonInit({ "message0": "item # of %1 in %2", "args0": [{"type": "input_value", "name": "ITEM"}, {"type": "field_variable", "name": "LIST", "variableType": "list"}], "output": "Number", "style": "list_category" }); } };
Blockly.Blocks['data_lengthoflist'] = { init: function() { this.jsonInit({ "message0": "length of %1", "args0": [{"type": "field_variable", "name": "LIST", "variableType": "list"}], "output": "Number", "style": "list_category" }); } };
Blockly.Blocks['data_listcontainsitem'] = { init: function() { this.jsonInit({ "message0": "%1 contains %2?", "args0": [{"type": "field_variable", "name": "LIST", "variableType": "list"}, {"type": "input_value", "name": "ITEM"}], "output": "Boolean", "style": "list_category" }); } };
Blockly.Blocks['data_showlist'] = { init: function() { this.jsonInit({ "message0": "show list %1", "args0": [{"type": "field_variable", "name": "LIST", "variableType": "list"}], "previousStatement": null, "nextStatement": null, "style": "list_category" }); } };
Blockly.Blocks['data_hidelist'] = { init: function() { this.jsonInit({ "message0": "hide list %1", "args0": [{"type": "field_variable", "name": "LIST", "variableType": "list"}], "previousStatement": null, "nextStatement": null, "style": "list_category" }); } };