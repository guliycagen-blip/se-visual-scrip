// src/modes/se/toolbox.js

export const toolbox = {
  'kind': 'categoryToolbox',
  'contents': [
    {
      'kind': 'category',
      'name': 'Events',
      'categorystyle': 'variable_category', // Используем простые строки
      'contents': [
        {'kind': 'block', 'type': 'event_whenflagclicked'},
      ],
    },
    {
      'kind': 'category',
      'name': 'Control',
      'categorystyle': 'loop_category', // Используем простые строки
      'contents': [
        {'kind': 'block', 'type': 'control_wait'},
        {'kind': 'block', 'type': 'control_repeat'},
        {'kind': 'block', 'type': 'control_forever'},
        {'kind': 'block', 'type': 'control_if'},
        {'kind': 'block', 'type': 'control_if_else'},
        {'kind': 'block', 'type': 'control_wait_until'},
        {'kind': 'block', 'type': 'control_repeat_until'},
        {'kind': 'block', 'type': 'control_stop'},
      ],
    },
    {
      'kind': 'category',
      'name': 'Operators',
      'categorystyle': 'math_category', // Используем простые строки
      'contents': [
        {'kind': 'block', 'type': 'operator_add'},
        {'kind': 'block', 'type': 'operator_subtract'},
        {'kind': 'block', 'type': 'operator_multiply'},
        {'kind': 'block', 'type': 'operator_divide'},
        {'kind': 'block', 'type': 'operator_random'},
        {'kind': 'block', 'type': 'operator_lt'},
        {'kind': 'block', 'type': 'operator_equals'},
        {'kind': 'block', 'type': 'operator_gt'},
        {'kind': 'block', 'type': 'operator_and'},
        {'kind': 'block', 'type': 'operator_or'},
        {'kind': 'block', 'type': 'operator_not'},
        {'kind': 'block', 'type': 'operator_join'},
        {'kind': 'block', 'type': 'operator_letter_of'},
        {'kind': 'block', 'type': 'operator_length'},
        {'kind': 'block', 'type': 'operator_contains'},
        {'kind': 'block', 'type': 'operator_mod'},
        {'kind': 'block', 'type': 'operator_round'},
        {'kind': 'block', 'type': 'operator_mathop'},
      ],
    },
    {
      'kind': 'category',
      'name': 'Sensing',
      'categorystyle': 'logic_category', // Используем простые строки
      'contents': [
        {'kind': 'block', 'type': 'sensing_askandwait'},
        {'kind': 'block', 'type': 'sensing_answer'},
        // ... другие блоки, если они есть
      ],
    },
    {
      'kind': 'category',
      'name': 'Data',
      'categorystyle': 'variable_category', // Используем простые строки
      'custom': 'VARIABLE', // Для стандартных переменных
    },
    {
      'kind': 'category',
      'name': 'My Blocks',
      'categorystyle': 'procedure_category', // Используем простые строки
      'custom': 'PROCEDURE', // Для функций
    },
  ],
};