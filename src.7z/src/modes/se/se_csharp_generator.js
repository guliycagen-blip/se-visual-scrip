// src/modes/se/se_csharp_generator.js

import * as Blockly from 'blockly/core';

// Регистрируем все правила для блоков SE в глобальном пространстве имен Blockly.CSharp
// Файл /src/modes/se/index.js затем соберет их в чистый, изолированный экземпляр генератора.

// --- ГЕНЕРАТОР СТРУКТУРЫ ---
Blockly.CSharp['se_program_structure'] = function(block) {
    const mainCode = Blockly.CSharp.statementToCode(block, 'MAIN') || '';
    const globalsCode = Blockly.CSharp.statementToCode(block, 'GLOBALS') || '';

    // Собираем переменные
    const TYPE_MAP = {
        'Number': 'double',
        'String': 'string',
        'Boolean': 'bool',
        'Colour': 'Color', // Убедитесь, что тип переменной цвета называется 'Colour'
        'Vector3D': 'Vector3D',
        'Vector2D': 'Vector2',
        'EntityInfo': 'MyDetectedEntityInfo',
        'MyDetectedEntityInfo': 'MyDetectedEntityInfo',
        'Array': 'List<IMyTerminalBlock>' // Обработка списков
    };
    
    const variables = block.workspace.getVariableMap().getAllVariables();
    const variableDeclarations = variables
      .map(v => {
          if (!v.type) return null; // Пропускаем переменные без типа
          const varType = TYPE_MAP[v.type] || 'object'; // 'object' как тип по умолчанию
          return `${varType} ${Blockly.CSharp.getVariableName(v.getId())};`;
      })
      .filter(declaration => declaration !== null)
      .join('\n');

    // Собираем финальный шаблон
    let code = `// Global variable declarations
${variableDeclarations}

// Global methods and definitions
${globalsCode}

public Program()
{
    // The constructor, called only once every session and
    // always before any other method is called.
}

public void Save()
{
    // Called when the program needs to save its state. Use
    // this method to save your state to the Storage field
    // or some other means.
}

void Main(string argument, UpdateType updateSource)
{
${mainCode.split('\n').map(l => l ? '    ' + l : '').join('\n')}
}
`;
    // Удаляем лишние пустые строки в начале
    return code.trim();
};


Blockly.CSharp['se_set_update_frequency'] = function(block) {
    const frequency = block.getFieldValue('FREQUENCY');
    return `Runtime.UpdateFrequency = UpdateFrequency.${frequency};\n`;
};

// --- ОБЩИЕ ГЕНЕРАТОРЫ ---
Blockly.CSharp['se_get_typed_block_by_name'] = function (block) {
    const blockName = Blockly.CSharp.valueToCode(block, 'BLOCK_NAME', Blockly.CSharp.ORDER_ATOMIC) || '""';
    const blockType = block.getFieldValue('BLOCK_TYPE');
    const code = `GridTerminalSystem.GetBlockWithName(${blockName}) as ${blockType}`;
    return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_get_blocks_of_type'] = function (block) {
    const blockType = block.getFieldValue('BLOCK_TYPE');
    const code = `new Func<List<${blockType}>>(() => { var list = new List<${blockType}>(); GridTerminalSystem.GetBlocksOfType<${blockType}>(list); return list; })()`;
    return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_get_blocks_in_group'] = function (block) {
    const groupName = Blockly.CSharp.valueToCode(block, 'GROUP_NAME', Blockly.CSharp.ORDER_ATOMIC) || '""';
    const code = `((Func<List<IMyTerminalBlock>>)(() => {
    var list = new List<IMyTerminalBlock>();
    var group = GridTerminalSystem.GetBlockGroupWithName(${groupName});
    if (group != null) group.GetBlocks(list);
    return list;
}))()`;
    return [code.trim(), Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_is_block_found'] = function(block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const code = `(${blockCode} != null)`;
    return [code, Blockly.CSharp.ORDER_EQUALITY];
};

Blockly.CSharp['se_set_enabled'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const enabled = Blockly.CSharp.valueToCode(block, 'ENABLED', Blockly.CSharp.ORDER_ATOMIC) || 'false';
    return `var b = (${blockCode}) as IMyFunctionalBlock; if (b != null) b.Enabled = ${enabled};\n`;
};

Blockly.CSharp['se_set_use_conveyor'] = function(block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const enabled = Blockly.CSharp.valueToCode(block, 'ENABLED', Blockly.CSharp.ORDER_ASSIGNMENT) || 'false';
    const code = `var funcBlock = (${blockCode}) as IMyFunctionalBlock; if (funcBlock != null) funcBlock.UseConveyorSystem = ${enabled};\n`;
    return code;
};

Blockly.CSharp['se_get_block_property_boolean'] = function(block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const property = block.getFieldValue('PROPERTY');
    const code = `((${blockCode}) as IMyTerminalBlock)?.${property} ?? false`;
    return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_echo'] = function (block) {
    const text = Blockly.CSharp.valueToCode(block, 'TEXT', Blockly.CSharp.ORDER_ATOMIC) || '""';
    return `Echo(${text}.ToString());\n`;
};

Blockly.CSharp['se_program_argument'] = function (block) {
    return ['argument', Blockly.CSharp.ORDER_ATOMIC];
};

// --- ГЕНЕРАТОРЫ ОСВЕЩЕНИЯ ---
Blockly.CSharp['se_light_set_color'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const color = block.getFieldValue('COLOR');
    const r = parseInt(color.substring(1, 3), 16);
    const g = parseInt(color.substring(3, 5), 16);
    const b = parseInt(color.substring(5, 7), 16);
    return `var l = (${blockCode}) as IMyLightingBlock; if (l != null) l.Color = new Color(${r}, ${g}, ${b});\n`;
};

Blockly.CSharp['se_light_set_radius'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const radius = Blockly.CSharp.valueToCode(block, 'RADIUS', Blockly.CSharp.ORDER_ASSIGNMENT) || '10.0f';
    return `var l = (${blockCode}) as IMyLightingBlock; if (l != null) l.Radius = (float)(${radius});\n`;
};

Blockly.CSharp['se_light_set_intensity'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const intensity = Blockly.CSharp.valueToCode(block, 'INTENSITY', Blockly.CSharp.ORDER_ASSIGNMENT) || '5.0f';
    return `var l = (${blockCode}) as IMyLightingBlock; if (l != null) l.Intensity = (float)(${intensity});\n`;
};

// ... (и так далее для всех остальных блоков, просто заменяем 'csharpGenerator.forBlock' на 'Blockly.CSharp')

// Я пройду и заменю всё. Просто скопируйте файл целиком.

Blockly.CSharp['se_piston_set_velocity'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const velocity = Blockly.CSharp.valueToCode(block, 'VELOCITY', Blockly.CSharp.ORDER_ASSIGNMENT) || '0';
  return `var p = (${blockCode}) as IMyPistonBase; if (p != null) p.Velocity = (float)${velocity};\n`;
};

Blockly.CSharp['se_piston_change_limit'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const limitType = block.getFieldValue('LIMIT_TYPE');
    const value = Blockly.CSharp.valueToCode(block, 'VALUE', Blockly.CSharp.ORDER_ASSIGNMENT) || '0.0f';
    return `var p = (${blockCode}) as IMyPistonBase; if (p != null) p.${limitType} = (float)(${value});\n`;
};

Blockly.CSharp['se_piston_get_position'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const code = `((${blockCode}) as IMyPistonBase)?.CurrentPosition ?? 0.0f`;
    return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_piston_get_status'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMyPistonBase)?.Status.ToString() ?? "Unknown"`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_rotor_set_velocity'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const velocity = Blockly.CSharp.valueToCode(block, 'VELOCITY', Blockly.CSharp.ORDER_ASSIGNMENT) || '10.0f';
    return `var r = (${blockCode}) as IMyMotorStator; if (r != null) r.TargetVelocityRPM = (float)(${velocity});\n`;
};

Blockly.CSharp['se_rotor_set_limits'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const lower = Blockly.CSharp.valueToCode(block, 'LOWER', Blockly.CSharp.ORDER_ASSIGNMENT) || 'float.MinValue';
  const upper = Blockly.CSharp.valueToCode(block, 'UPPER', Blockly.CSharp.ORDER_ASSIGNMENT) || 'float.MaxValue';
  return `var r = (${blockCode}) as IMyMotorStator; if (r != null) { r.LowerLimitDeg = (float)${lower}; r.UpperLimitDeg = (float)${upper}; }\n`;
};

Blockly.CSharp['se_rotor_get_angle'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const code = `(((${blockCode}) as IMyMotorStator)?.Angle ?? 0.0f) * (180.0f / (float)Math.PI)`;
    return [code, Blockly.CSharp.ORDER_MULTIPLICATIVE];
};

Blockly.CSharp['se_landing_gear_lock_unlock'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const action = block.getFieldValue('ACTION');
  return `((${blockCode}) as IMyLandingGear)?.${action}();\n`;
};

Blockly.CSharp['se_landing_gear_get_status'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMyLandingGear)?.Status.ToString() ?? "Unknown"`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_connector_lock_unlock'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const action = block.getFieldValue('ACTION');
  return `((${blockCode}) as IMyShipConnector)?.ApplyAction("${action}");\n`;
};

Blockly.CSharp['se_connector_get_status'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMyShipConnector)?.Status.ToString() ?? "Unknown"`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_thruster_set_override'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const override = Blockly.CSharp.valueToCode(block, 'OVERRIDE', Blockly.CSharp.ORDER_ASSIGNMENT) || '0.0f';
    return `var t = (${blockCode}) as IMyThrust; if (t != null) t.ThrustOverridePercentage = (float)(${override}) / 100.0f;\n`;
};

Blockly.CSharp['se_thruster_get_thrust'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const code = `((${blockCode}) as IMyThrust)?.CurrentThrust ?? 0.0f`;
    return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_gyro_set_override'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const enabled = Blockly.CSharp.valueToCode(block, 'ENABLED', Blockly.CSharp.ORDER_ASSIGNMENT) || 'false';
  const code = `var gyro = (${blockCode}) as IMyGyro; if (gyro != null) gyro.GyroOverride = ${enabled};\n`;
  return code;
};

Blockly.CSharp['se_gyro_set_rotation'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const axis = block.getFieldValue('AXIS');
  const value = Blockly.CSharp.valueToCode(block, 'VALUE', Blockly.CSharp.ORDER_ASSIGNMENT) || '0';
  const code = `var gyro = (${blockCode}) as IMyGyro; if (gyro != null) gyro.${axis} = (float)(${value} * Math.PI / 180.0);\n`;
  return code;
};

Blockly.CSharp['se_controller_is_under_control'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMyShipController)?.IsUnderControl ?? false`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_controller_get_gravity'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMyShipController)?.GetNaturalGravity() ?? Vector3D.Zero`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_inventory_get_fill_percent'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const code = `((Func<double>)(() => {
var inv = (${blockCode})?.GetInventory(0);
if (inv != null && (double)inv.MaxVolume > 0) return ((double)inv.CurrentVolume / (double)inv.MaxVolume) * 100.0;
return 0.0;
}))()`;
    return [code.trim(), Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_inventory_transfer_item'] = function(block) {
    const amount = Blockly.CSharp.valueToCode(block, 'AMOUNT', Blockly.CSharp.ORDER_ATOMIC) || '1';
    const itemSubtype = Blockly.CSharp.valueToCode(block, 'ITEM_SUBTYPE', Blockly.CSharp.ORDER_ATOMIC) || '""';
    const itemType = block.getFieldValue('ITEM_TYPE');
    const sourceBlock = Blockly.CSharp.valueToCode(block, 'FROM_BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const destBlock = Blockly.CSharp.valueToCode(block, 'TO_BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const code = `
{
var sourceEntity = (${sourceBlock}) as IMyEntity;
var destEntity = (${destBlock}) as IMyEntity;
if (sourceEntity != null && sourceEntity.HasInventory && destEntity != null && destEntity.HasInventory)
{
    var sourceInv = sourceEntity.GetInventory(0);
    var destInv = destEntity.GetInventory(0);
    var itemDef = MyDefinitionId.Parse("MyObjectBuilder_${itemType}/" + ${itemSubtype});
    var item = sourceInv.FindItem(itemDef);
    if (item.HasValue)
    {
        sourceInv.TransferItemTo(destInv, item.Value, (MyFixedPoint)(${amount}));
    }
}
}
`;
    return code;
};

Blockly.CSharp['se_inventory_get_item_amount'] = function(block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const itemSubtype = Blockly.CSharp.quote_(block.getFieldValue('ITEM_TYPE'));
    const code = `((Func<long>)(() => {
var entity = (${blockCode}) as IMyEntity;
if (entity == null || !entity.HasInventory) return 0;
var inventory = entity.GetInventory(0);
var itemDefinition = MyDefinitionId.Parse("MyObjectBuilder_Component/" + ${itemSubtype});
return (long)inventory.GetItemAmount(itemDefinition);
}))()`;
    return [code, Blockly.CSharp.ORDER_ATOMIC];
};

Blockly.CSharp['se_assembler_add_to_queue'] = function(block) {
    const amount = Blockly.CSharp.valueToCode(block, 'AMOUNT', Blockly.CSharp.ORDER_ATOMIC) || '1';
    const blueprintId = Blockly.CSharp.quote_(block.getFieldValue('BLUEPRINT_ID'));
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const code = `
{
var asm = (${blockCode}) as IMyAssembler;
if (asm != null)
{
    var blueprint = MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/" + ${blueprintId});
    asm.AddQueueItem(blueprint, (decimal)(${amount}));
}
}
`;
    return code;
};

Blockly.CSharp['se_assembler_get_queue_amount'] = function(block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const blueprintId = Blockly.CSharp.quote_(block.getFieldValue('BLUEPRINT_ID'));
    const code = `((Func<long>)(() => {
var asm = (${blockCode}) as IMyAssembler;
if (asm == null) return 0;
var queue = new List<MyProductionItem>();
asm.GetQueue(queue);
long totalAmount = 0;
string targetBlueprint = "MyObjectBuilder_BlueprintDefinition/" + ${blueprintId};
foreach (var item in queue)
{
    if (item.BlueprintId.ToString() == targetBlueprint)
    {
        totalAmount += (long)item.Amount;
    }
}
return totalAmount;
}))()`;
    return [code, Blockly.CSharp.ORDER_ATOMIC];
};

Blockly.CSharp['se_assembler_set_repeating'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const repeating = Blockly.CSharp.valueToCode(block, 'REPEATING', Blockly.CSharp.ORDER_ASSIGNMENT) || 'false';
  return `var asm = (${blockCode}) as IMyAssembler; if (asm != null) asm.Repeating = ${repeating};\n`;
};

Blockly.CSharp['se_production_is_working'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const code = `((${blockCode}) as IMyProductionBlock)?.IsWorking ?? false`;
    return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_battery_get_charge'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const chargeType = block.getFieldValue('CHARGE_TYPE');
    let code = '0.0';
    switch (chargeType) {
    case 'CURRENT_PERCENT':
        // ...
        return [code.trim(), Blockly.CSharp.ORDER_FUNCTION_CALL];
    case 'CURRENT_MWH':
        code = `((${blockCode}) as IMyBatteryBlock)?.CurrentStoredPower ?? 0.0f`;
        break;
    case 'MAX_MWH':
        code = `((${blockCode}) as IMyBatteryBlock)?.MaxStoredPower ?? 0.0f`;
        break;
    default:
        break; 
}
return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_battery_get_input'] = function(block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const code = `((${blockCode}) as IMyBatteryBlock)?.CurrentInput ?? 0.0f`;
    return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_battery_set_charge_mode'] = function(block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const mode = block.getFieldValue('MODE');
    const code = `var batt = (${blockCode}) as IMyBatteryBlock; if (batt != null) batt.ChargeMode = ChargeMode.${mode};\n`;
    return code;
};

Blockly.CSharp['se_power_get_output'] = function (block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const code = `((${blockCode}) as IMyPowerProducer)?.CurrentOutput ?? 0.0f`;
    return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_power_get_max_output'] = function(block) {
    const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
    const code = `((${blockCode}) as IMyPowerProducer)?.MaxOutput ?? 0.0f`;
    return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_lcd_write_text'] = function(block) {
  const text = Blockly.CSharp.valueToCode(block, 'TEXT', Blockly.CSharp.ORDER_ATOMIC) || '""';
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMyTextPanel)?.WriteText(${text}.ToString(), false);\n`;
  return code;
};

Blockly.CSharp['se_lcd_append_text'] = function(block) {
  const text = Blockly.CSharp.valueToCode(block, 'TEXT', Blockly.CSharp.ORDER_ATOMIC) || '""';
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMyTextPanel)?.WriteText("\\n" + ${text}.ToString(), true);\n`;
  return code;
};

Blockly.CSharp['se_lcd_clear'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMyTextPanel)?.WriteText("", false);\n`;
  return code;
};

Blockly.CSharp['se_lcd_set_font_size'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const size = Blockly.CSharp.valueToCode(block, 'SIZE', Blockly.CSharp.ORDER_ASSIGNMENT) || '1.0';
  const code = `var panel = (${blockCode}) as IMyTextPanel; if (panel != null) panel.FontSize = (float)${size};\n`;
  return code;
};

Blockly.CSharp['se_lcd_set_color'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const target = block.getFieldValue('TARGET');
  const colorHex = block.getFieldValue('COLOR');
  const r = parseInt(colorHex.substring(1, 3), 16);
  const g = parseInt(colorHex.substring(3, 5), 16);
  const b = parseInt(colorHex.substring(5, 7), 16);
  const code = `var panel = (${blockCode}) as IMyTextPanel; if (panel != null) panel.${target} = new Color(${r}, ${g}, ${b});\n`;
  return code;
};

Blockly.CSharp['se_sensor_get_last_detected'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMySensorBlock)?.LastDetectedEntity ?? new MyDetectedEntityInfo()`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_entity_info_is_empty'] = function(block) {
  const entityInfo = Blockly.CSharp.valueToCode(block, 'ENTITY_INFO', Blockly.CSharp.ORDER_ATOMIC) || 'new MyDetectedEntityInfo()';
  const code = `${entityInfo}.IsEmpty()`;
  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_entity_info_get_property'] = function(block) {
  const entityInfo = Blockly.CSharp.valueToCode(block, 'ENTITY_INFO', Blockly.CSharp.ORDER_ATOMIC) || 'new MyDetectedEntityInfo()';
  const property = block.getFieldValue('PROPERTY');
  let code = `${entityInfo}.${property}`;
  if (property === 'Type' || property === 'Relationship') {
    code += '.ToString()';
  }
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_timer_control'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const action = block.getFieldValue('ACTION');
  return `((${blockCode}) as IMyTimerBlock)?.ApplyAction("${action}");\n`;
};

Blockly.CSharp['se_timer_set_delay'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const delay = Blockly.CSharp.valueToCode(block, 'DELAY', Blockly.CSharp.ORDER_ASSIGNMENT) || '0';
  const code = `var t = (${blockCode}) as IMyTimerBlock; if (t != null) t.TriggerDelay = (float)${delay};\n`;
  return code;
};

Blockly.CSharp['se_timer_is_counting_down'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMyTimerBlock)?.IsCountingDown ?? false`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_vector_create'] = function(block) {
  const x = Blockly.CSharp.valueToCode(block, 'X', Blockly.CSharp.ORDER_ATOMIC) || '0';
  const y = Blockly.CSharp.valueToCode(block, 'Y', Blockly.CSharp.ORDER_ATOMIC) || '0';
  const z = Blockly.CSharp.valueToCode(block, 'Z', Blockly.CSharp.ORDER_ATOMIC) || '0';
  const code = `new Vector3D(${x}, ${y}, ${z})`;
  return [code, Blockly.CSharp.ORDER_NEW];
};

Blockly.CSharp['se_vector_get_component'] = function(block) {
  const vector = Blockly.CSharp.valueToCode(block, 'VECTOR', Blockly.CSharp.ORDER_MEMBER) || 'Vector3D.Zero';
  const component = block.getFieldValue('COMPONENT');
  const code = `${vector}.${component}`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_vector_get_length'] = function(block) {
  const vector = Blockly.CSharp.valueToCode(block, 'VECTOR', Blockly.CSharp.ORDER_MEMBER) || 'Vector3D.Zero';
  const code = `${vector}.Length()`;
  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_weapon_shoot_toggle'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const action = block.getFieldValue('ACTION');
  return `((${blockCode}) as IMyUserControllableGun)?.ApplyAction("${action}");\n`;
};

Blockly.CSharp['se_weapon_shoot_once'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  return `((${blockCode}) as IMyUserControllableGun)?.ShootOnce();\n`;
};

Blockly.CSharp['se_weapon_get_ammo'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMyUserControllableGun)?.GetAmmunitionAmount() ?? 0`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_weapon_is_shooting'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `((${blockCode}) as IMyUserControllableGun)?.IsShooting ?? false`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_me'] = function(block) {
    return ['Me', Blockly.CSharp.ORDER_ATOMIC];
};

Blockly.CSharp['se_grid_get_property'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'Me';
  const property = block.getFieldValue('PROPERTY');
  let defaultValue = 'null';
  switch(property) {
    case 'DisplayName': defaultValue = '""'; break;
    case 'Mass': defaultValue = '0'; break;
    case 'IsStatic': defaultValue = 'false'; break;
  }
  const code = `((${blockCode})?.CubeGrid.${property} ?? ${defaultValue})`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_storage_write'] = function(block) {
  const value = Blockly.CSharp.valueToCode(block, 'VALUE', Blockly.CSharp.ORDER_ATOMIC) || '""';
  return `Me.Storage = ${value}.ToString();\n`;
};

Blockly.CSharp['se_storage_read'] = function(block) {
  return ['Storage', Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_controller_get_input'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const property = block.getFieldValue('PROPERTY');
  let defaultValue = 'default';
  if (property === 'MoveIndicator') defaultValue = 'Vector3D.Zero';
  if (property === 'RotationIndicator') defaultValue = 'Vector2.Zero';
  if (property === 'RollIndicator') defaultValue = '0f';
  const code = `((${blockCode}) as IMyShipController)?.${property} ?? ${defaultValue}`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_vector2d_create'] = function(block) {
  const x = Blockly.CSharp.valueToCode(block, 'X', Blockly.CSharp.ORDER_ATOMIC) || '0';
  const y = Blockly.CSharp.valueToCode(block, 'Y', Blockly.CSharp.ORDER_ATOMIC) || '0';
  const code = `new Vector2((float)${x}, (float)${y})`;
  return [code, Blockly.CSharp.ORDER_NEW];
};

Blockly.CSharp['se_vector2d_get_component'] = function(block) {
  const vector = Blockly.CSharp.valueToCode(block, 'VECTOR', Blockly.CSharp.ORDER_MEMBER) || 'Vector2.Zero';
  const component = block.getFieldValue('COMPONENT');
  const code = `${vector}.${component}`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_get_block_position'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const code = `(${blockCode})?.GetPosition() ?? Vector3D.Zero`;
  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_get_block_direction'] = function(block) {
  const blockCode = Blockly.CSharp.valueToCode(block, 'BLOCK', Blockly.CSharp.ORDER_ATOMIC) || 'null';
  const direction = block.getFieldValue('DIRECTION');
  const code = `(${blockCode})?.WorldMatrix.${direction} ?? Vector3D.Zero`;
  return [code, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['se_gps_to_vector'] = function(block) {
  const gpsString = Blockly.CSharp.valueToCode(block, 'GPS_STRING', Blockly.CSharp.ORDER_ATOMIC) || '""';
  const code = `((Func<Vector3D>)(() => {
    Vector3D vector;
    if (Vector3D.TryParse((${gpsString}), out vector)) return vector;
    string[] parts = (${gpsString}).Split(':');
    if (parts.Length == 6) {
    double x, y, z;
    if (double.TryParse(parts[2], out x) && double.TryParse(parts[3], out y) && double.TryParse(parts[4], out z))
        return new Vector3D(x, y, z);
    }
    return Vector3D.Zero;
    }))()`;
  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_vector_distance'] = function(block) {
  const vec1 = Blockly.CSharp.valueToCode(block, 'VEC1', Blockly.CSharp.ORDER_ATOMIC) || 'Vector3D.Zero';
  const vec2 = Blockly.CSharp.valueToCode(block, 'VEC2', Blockly.CSharp.ORDER_ATOMIC) || 'Vector3D.Zero';
  const code = `Vector3D.Distance(${vec1}, ${vec2})`;
  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_vector_normalize'] = function(block) {
  const vector = Blockly.CSharp.valueToCode(block, 'VECTOR', Blockly.CSharp.ORDER_ATOMIC) || 'Vector3D.Zero';
  const code = `Vector3D.Normalize(${vector})`;
  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_vector_dot_product'] = function(block) {
  const vec1 = Blockly.CSharp.valueToCode(block, 'VEC1', Blockly.CSharp.ORDER_ATOMIC) || 'Vector3D.Zero';
  const vec2 = Blockly.CSharp.valueToCode(block, 'VEC2', Blockly.CSharp.ORDER_ATOMIC) || 'Vector3D.Zero';
  const code = `Vector3D.Dot(${vec1}, ${vec2})`;
  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_vector_math_op'] = function(block) {
  const operator = block.getFieldValue('OP');
  const order = (operator === 'MULTIPLY' || operator === 'DIVIDE') ? 
                Blockly.CSharp.ORDER_MULTIPLICATIVE : Blockly.CSharp.ORDER_ADDITIVE;
  const valueA = Blockly.CSharp.valueToCode(block, 'A', order) || 'new Vector3D()';
  const valueB = Blockly.CSharp.valueToCode(block, 'B', order) || 'new Vector3D()';
  let code;
  switch (operator) {
    case 'ADD': code = `${valueA} + ${valueB}`; break;
    case 'MINUS': code = `${valueA} - ${valueB}`; break;
    case 'CROSS':
      code = `Vector3D.Cross(${valueA}, ${valueB})`;
      return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
    case 'MULTIPLY': code = `${valueA} * ${valueB}`; break;
    case 'DIVIDE': code = `${valueA} / ${valueB}`; break;
    default: throw Error('Unknown operator: ' + operator);
  }
  return [code, order];
};

Blockly.CSharp['se_camera_raycast'] = function(block) {
    const functionName = Blockly.CSharp.provideFunction_(
        'CameraRaycastSafe',
        `
MyDetectedEntityInfo ${Blockly.CSharp.FUNCTION_NAME_PLACEHOLDER_}(IMyCameraBlock camera, double distance, float pitch = 0f, float yaw = 0f)
{
    if (camera == null || !camera.IsWorking) return new MyDetectedEntityInfo();
    camera.EnableRaycast = true;
    if (!camera.CanScan(distance)) return new MyDetectedEntityInfo();
    return camera.Raycast(distance, pitch, yaw);
}`
    );
    const camera = Blockly.CSharp.valueToCode(block, 'CAMERA', Blockly.CSharp.ORDER_NONE) || 'null';
    const distance = Blockly.CSharp.valueToCode(block, 'DISTANCE', Blockly.CSharp.ORDER_NONE) || '0';
    const pitch = Blockly.CSharp.valueToCode(block, 'PITCH', Blockly.CSharp.ORDER_NONE) || '0';
    const yaw = Blockly.CSharp.valueToCode(block, 'YAW', Blockly.CSharp.ORDER_NONE) || '0';
    const code = `${functionName}(${camera}, ${distance}, (float)${pitch}, (float)${yaw})`;
    return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['se_camera_raycast_is_valid'] = function(block) {
    const entityInfo = Blockly.CSharp.valueToCode(block, 'ENTITY_INFO', Blockly.CSharp.ORDER_MEMBER) || 'new MyDetectedEntityInfo()';
    const code = `!${entityInfo}.IsEmpty()`;
    return [code, Blockly.CSharp.ORDER_LOGICAL_NOT];
};

Blockly.CSharp['se_camera_raycast_get_property'] = function(block) {
    const entityInfo = Blockly.CSharp.valueToCode(block, 'ENTITY_INFO', Blockly.CSharp.ORDER_MEMBER) || 'new MyDetectedEntityInfo()';
    const property = block.getFieldValue('PROPERTY');
    let code;
    let order;
    switch (property) {
    case 'Name': code = `${entityInfo}.Name`; order = Blockly.CSharp.ORDER_MEMBER; break;
    case 'Type': code = `${entityInfo}.Type.ToString()`; order = Blockly.CSharp.ORDER_FUNCTION_CALL; break;
    case 'Relationship': code = `${entityInfo}.Relationship.ToString()`; order = Blockly.CSharp.ORDER_FUNCTION_CALL; break;
    case 'Velocity': code = `${entityInfo}.Velocity`; order = Blockly.CSharp.ORDER_MEMBER; break;
    case 'HitPosition':
         code = `(${entityInfo}.HitPosition.HasValue ? ${entityInfo}.HitPosition.Value : Vector3D.Zero)`;
        order = Blockly.CSharp.ORDER_CONDITIONAL;
        break;
    case 'EntityId': code = `${entityInfo}.EntityId`; order = Blockly.CSharp.ORDER_MEMBER; break;
    default: 
        code = 'null'; 
        order = Blockly.CSharp.ORDER_ATOMIC; 
        break;
}
    return [code, order];
};