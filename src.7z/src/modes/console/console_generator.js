// src/modes/console/console_generator.js
import * as Blockly from 'blockly/core';

// ЗАМЕТКА: Мы больше не импортируем generator_instance.
// Вместо этого, мы регистрируем правила в глобальном пространстве имен Blockly.CSharp
// Наши "bootstrap" файлы (index.js) затем соберут их в чистый экземпляр генератора.

Blockly.CSharp['program_main'] = function(block) {
  var statements_main = Blockly.CSharp.statementToCode(block, 'main_code');
  // Вся обертка (using, namespace, class, Main) теперь делается в файле
  // /modes/console/index.js в методе consoleGenerator.finish()
  return statements_main;
};

Blockly.CSharp['console_writeline'] = function(block) {
  var value_text = Blockly.CSharp.valueToCode(block, 'TEXT', Blockly.CSharp.ORDER_ATOMIC) || '""';
  Blockly.CSharp.definitions_['using_system'] = 'using System;';
  return `Console.WriteLine(${value_text});\n`;
};

Blockly.CSharp['console_readline'] = function(block) {
  Blockly.CSharp.definitions_['using_system'] = 'using System;';
  return ['Console.ReadLine()', Blockly.CSharp.ORDER_ATOMIC];
};


// --- НОВЫЕ ГЕНЕРАТОРЫ ДЛЯ БЛОКОВ ПЕРЕМЕННЫХ ---

Blockly.CSharp['math_operation'] = function(block) {
  const operator = block.getFieldValue('OP');
  
  // Используем Blockly.CSharp для получения кода и констант порядка
  const argument0 = Blockly.CSharp.valueToCode(block, 'A', Blockly.CSharp.ORDER_ATOMIC) || '0';
  const argument1 = Blockly.CSharp.valueToCode(block, 'B', Blockly.CSharp.ORDER_ATOMIC) || '0';
  
  const operatorMap = {
    'ADD':    [' + ', Blockly.CSharp.ORDER_ADDITION],
    'MINUS':  [' - ', Blockly.CSharp.ORDER_SUBTRACTION],
    'MULTIPLY':[' * ', Blockly.CSharp.ORDER_MULTIPLICATION],
    'DIVIDE': [' / ', Blockly.CSharp.ORDER_DIVISION],
  };

  const [op_str, order] = operatorMap[operator];
  
  const code = argument0 + op_str + argument1;
  return [code, order];
};


Blockly.CSharp['convert_to_number'] = function(block) {
  const conversionType = block.getFieldValue('TYPE');
  const textToConvert = Blockly.CSharp.valueToCode(block, 'TEXT_TO_CONVERT', Blockly.CSharp.ORDER_ATOMIC) || '""';
  
  let code = '';
  switch (conversionType) {
    case 'INT':
      code = `int.Parse(${textToConvert})`;
      break;
    case 'DOUBLE':
      code = `double.Parse(${textToConvert})`;
      break;
  }
  
  // Убедимся, что using System; будет добавлен
  Blockly.CSharp.definitions_['using_system'] = 'using System;';

  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};