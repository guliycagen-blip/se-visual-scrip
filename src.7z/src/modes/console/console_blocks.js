import * as Blockly from 'blockly/core';

const programColour = '#5b6770';
const ioColour = "#5b80a5";

Blockly.Blocks['program_main'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Создать консольную программу C#");
    this.appendStatementInput("BODY")
        .setCheck(null);
    this.setColour(programColour);
    this.setTooltip("Главный блок для создания полноценной программы. Весь код внутри будет помещен в метод Main().");
    this.setDeletable(false); // Этот блок нельзя удалить
    this.setMovable(false);  // и нельзя передвинуть
    this.setPreviousStatement(false, null);
    this.setNextStatement(false, null);
  }
};

Blockly.Blocks['console_writeline'] = {
  init: function() {
    this.appendValueInput("TEXT_TO_WRITE")
        .setCheck(["String", "Number", "Boolean"])
        .appendField("вывести в консоль");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(ioColour);
    this.setTooltip("Выводит указанное значение в консоль с новой строки.");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['console_readline'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("прочитать строку из консоли");
    this.setOutput(true, "String");
    this.setColour(ioColour);
    this.setTooltip("Читает следующую строку из консоли и возвращает ее как текст.");
    this.setHelpUrl("");
  }
};

// Блок для присваивания значения переменной
Blockly.Blocks['variables_set'] = {
  init: function() {
    this.appendValueInput("VALUE")
        .setCheck(null)
        .appendField("установить")
        .appendField(new Blockly.FieldVariable("переменная"), "VAR")
        .appendField("в");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(330); // Стандартный цвет для переменных
    this.setTooltip("Присвоить значение переменной.");
    this.setHelpUrl(Blockly.Msg.VARIABLES_SET_HELPURL);
  }
};

// Блок для получения значения переменной
Blockly.Blocks['variables_get'] = {
  init:function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldVariable("переменная"), "VAR");
    this.setOutput(true, null);
    this.setColour(330); // Стандартный цвет для переменных
    this.setTooltip(Blockly.Msg.VARIABLES_GET_TOOLTIP);
    this.setHelpUrl(Blockly.Msg.VARIABLES_GET_HELPURL);
  }
};

Blockly.Blocks['math_operation'] = {
  init: function() {
    this.appendValueInput("A")
        .setCheck("Number");
    this.appendDummyInput()
        .appendField(new Blockly.FieldDropdown([
          ["+", "ADD"],
          ["-", "MINUS"],
          ["×", "MULTIPLY"],
          ["÷", "DIVIDE"]
        ]), "OP");
    this.appendValueInput("B")
        .setCheck("Number");
    this.setInputsInline(true);
    this.setOutput(true, "Number"); // Этот блок возвращает значение
    this.setColour(230);
    this.setTooltip("Выполняет математическую операцию");
    this.setHelpUrl("");
  }
};

Blockly.Blocks['convert_to_number'] = {
  init: function() {
    this.appendValueInput("TEXT_TO_CONVERT")
        .setCheck("String") // Принимает только текст
        .appendField("преобразовать в")
        .appendField(new Blockly.FieldDropdown([
            ["целое число (int)", "INT"],
            ["дробное число (double)", "DOUBLE"]
        ]), "TYPE");
    this.setOutput(true, "Number"); // Возвращает число
    this.setColour(230); // Цвет как у математических блоков
    this.setTooltip("Преобразует текстовую строку в числовой тип.");
    this.setHelpUrl("");
  }
};