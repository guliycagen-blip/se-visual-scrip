// src/modes/console/toolbox.js

export const toolbox = {
  kind: 'categoryToolbox',
  contents: [
    // --- ИСПРАВЛЕНО: Заменено свойство 'colour' на 'categorystyle' ---
    { kind: 'category', name: 'Логика', categorystyle: 'logic_category', contents: [ { kind: 'block', type: 'controls_if' }, { kind: 'block', type: 'logic_compare' }, { kind: 'block', type: 'logic_operation' }, { kind: 'block', type: 'logic_negate' }, { kind: 'block', type: 'logic_boolean' }, { kind: 'block', type: 'logic_null' } ] },
    { kind: 'category', name: 'Циклы', categorystyle: 'loop_category', contents: [ { kind: 'block', type: 'controls_repeat_ext' }, { kind: 'block', type: 'controls_whileUntil' }, { kind: 'block', type: 'controls_for' }, { kind: 'block', type: 'controls_forEach' }, { kind: 'block', type: 'controls_flow_statements' } ] },
    { kind: 'category', name: 'Математика', categorystyle: 'math_category', contents: [ { kind: 'block', type: 'math_operation' }, { kind: 'block', type: 'math_number' }, { kind: 'block', type: 'math_arithmetic' } ] },
    { kind: 'category', name: 'Текст', categorystyle: 'text_category', contents: [ { kind: 'block', type: 'text' }, { kind: 'block', type: 'text_join' } ] },
    { kind: 'category', name: 'Списки', categorystyle: 'list_category', contents: [ { kind: 'block', type: 'lists_create_with' } ] },
    { kind: 'sep' },
    { kind: 'category', name: 'Консоль', categorystyle: 'text_category', contents: [ { kind: 'block', type: 'console_writeline' }, { kind: 'block', type: 'console_readline' }, ]},
    { kind: 'sep' },
    { kind: 'category', name: 'Переменные', categorystyle: 'variable_category', custom: 'VARIABLE' },
    { kind: 'category', name: 'Функции', categorystyle: 'procedure_category', custom: 'PROCEDURE' },
    { kind: 'category', name: 'Преобразование', categorystyle: 'math_category', contents: [ { kind: 'block', type: 'convert_to_number' } ]},
  ]
};