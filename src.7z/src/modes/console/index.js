// src/modes/console/index.js

import * as Blockly from 'blockly/core';
// ВАЖНО: Импортируем стандартный C# генератор по правильному пути
import '../../generator/csharp.js'; // <-- Импортируем наш локальный файл

// --- ИСПРАВЛЕНИЕ ЗДЕСЬ ---
// 1. Загружаем определения НАШИХ кастомных блоков для консоли
import './console_blocks.js'; 
// 2. Загружаем генераторы кода для НАШИХ кастомных блоков
import './console_generator.js'; 
// -------------------------

// Генераторы кода для СТАНДАРТНЫХ блоков
import '../standard_csharp_generator.js';

// Панель инструментов
import { toolbox } from './toolbox';

// Собираем финальную конфигурацию для этого режима
export const config = {
  toolbox: toolbox,
  theme: Blockly.Themes.Dark,
  renderer: 'zelos',
  // Указываем напрямую на стандартный, глобально доступный генератор
  generator: Blockly.CSharp,
  // Дополнительные опции
  workspaceOptions: {
    grid: {
      spacing: 20,
      length: 3,
      colour: '#ccc',
      snap: true,
    },
  },
};