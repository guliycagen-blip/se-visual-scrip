import * as Blockly from 'blockly/core';

export const ERROR_MESSAGE_STRING = '"Ошибка: несовместимые блоки"';

/**
 * Устанавливает предупреждение на блок и возвращает стандартный код ошибки.
 * @param {Blockly.Block} block Блок, на котором произошла ошибка.
 * @param {string} warningText Текст предупреждения для пользователя.
 * @returns {[string, number]} Кортеж с кодом ошибки и приоритетом операции.
 */
function handleBlockError(block, warningText) {
  block.setWarningText(warningText);
  return [ERROR_MESSAGE_STRING, Blockly.CSharp.ORDER_ATOMIC];
}

// --- ЛОГИКА ---
Blockly.CSharp['controls_if'] = function(block) {
  let n = 0;
  let code = '';
  let branchCode, conditionCode;
  do {
    conditionCode = Blockly.CSharp.valueToCode(block, 'IF' + n, Blockly.CSharp.ORDER_NONE) || 'false';
    branchCode = Blockly.CSharp.statementToCode(block, 'DO' + n) || '';
    code += (n > 0 ? 'else ' : '') + 'if (' + conditionCode + ') {\n' + branchCode + '}';
    n++;
  } while (block.getInput('IF' + n));

  if (block.getInput('ELSE')) {
    branchCode = Blockly.CSharp.statementToCode(block, 'ELSE') || '';
    code += ' else {\n' + branchCode + '}';
  }
  return code + '\n';
};

Blockly.CSharp['logic_compare'] = function(block) {
  const OPERATORS = { 'EQ': '==', 'NEQ': '!=', 'LT': '<', 'LTE': '<=', 'GT': '>', 'GTE': '>=' };
  const operator = OPERATORS[block.getFieldValue('OP')];
  const order = (operator === '==' || operator === '!=') ? Blockly.CSharp.ORDER_EQUALITY : Blockly.CSharp.ORDER_RELATIONAL;
  const argument0 = Blockly.CSharp.valueToCode(block, 'A', order) || '0';
  const argument1 = Blockly.CSharp.valueToCode(block, 'B', order) || '0';
  const code = `${argument0} ${operator} ${argument1}`;
  return [code, order];
};

Blockly.CSharp['logic_operation'] = function(block) {
  const OPERATORS = { 'AND': '&&', 'OR': '||' };
  const operator = OPERATORS[block.getFieldValue('OP')];
  const order = (operator === '&&') ? Blockly.CSharp.ORDER_LOGICAL_AND : Blockly.CSharp.ORDER_LOGICAL_OR;
  let argument0 = Blockly.CSharp.valueToCode(block, 'A', order) || 'false';
  let argument1 = Blockly.CSharp.valueToCode(block, 'B', order) || 'false';
  const code = `${argument0} ${operator} ${argument1}`;
  return [code, order];
};

Blockly.CSharp['logic_negate'] = function(block) {
  const order = Blockly.CSharp.ORDER_UNARY_PREFIX;
  const argument0 = Blockly.CSharp.valueToCode(block, 'BOOL', order) || 'true';
  const code = '!' + argument0;
  return [code, order];
};

Blockly.CSharp['logic_boolean'] = function(block) {
  const code = (block.getFieldValue('BOOL') === 'TRUE') ? 'true' : 'false';
  return [code, Blockly.CSharp.ORDER_ATOMIC];
};

Blockly.CSharp['logic_null'] = function(block) {
  return ['null', Blockly.CSharp.ORDER_ATOMIC];
};

// --- ЦИКЛЫ ---
Blockly.CSharp['controls_repeat_ext'] = function(block) {
  const repeats = Blockly.CSharp.valueToCode(block, 'TIMES', Blockly.CSharp.ORDER_ASSIGNMENT) || '0';
  let branch = Blockly.CSharp.statementToCode(block, 'DO') || '';
  let loopVar = Blockly.CSharp.variableDB_.getDistinctName('count', Blockly.Variables.NAME_TYPE);
  let code = `for (int ${loopVar} = 0; ${loopVar} < ${repeats}; ${loopVar}++) {\n${branch}}\n`;
  return code;
};

Blockly.CSharp['controls_for'] = function(block) {
  const variable = block.workspace.getVariableById(block.getFieldValue('VAR'));
  const variable0 = Blockly.CSharp.getVariableName(variable.getId());
  const from = Blockly.CSharp.valueToCode(block, 'FROM', Blockly.CSharp.ORDER_ASSIGNMENT) || '0';
  const to = Blockly.CSharp.valueToCode(block, 'TO', Blockly.CSharp.ORDER_ASSIGNMENT) || '0';
  const increment = Blockly.CSharp.valueToCode(block, 'BY', Blockly.CSharp.ORDER_ASSIGNMENT) || '1';
  let branch = Blockly.CSharp.statementToCode(block, 'DO') || '';
  return `for (double ${variable0} = ${from}; ${variable0} <= ${to}; ${variable0} += ${increment}) {\n${branch}}\n`;
};

Blockly.CSharp['controls_forEach'] = function(block) {
  const variable = block.workspace.getVariableById(block.getFieldValue('VAR'));
  const variable0 = Blockly.CSharp.getVariableName(variable.getId());
  const list = Blockly.CSharp.valueToCode(block, 'LIST', Blockly.CSharp.ORDER_ASSIGNMENT) || 'new List<object>()';
  let branch = Blockly.CSharp.statementToCode(block, 'DO') || '';
  return `foreach (var ${variable0} in ${list}) {\n${branch}}\n`;
};

Blockly.CSharp['controls_whileUntil'] = function(block) {
  const until = block.getFieldValue('MODE') === 'UNTIL';
  let argument0 = Blockly.CSharp.valueToCode(block, 'BOOL', until ? Blockly.CSharp.ORDER_UNARY_PREFIX : Blockly.CSharp.ORDER_NONE) || 'false';
  let branch = Blockly.CSharp.statementToCode(block, 'DO') || '';
  if (until) {
    argument0 = '!' + argument0;
  }
  return 'while (' + argument0 + ') {\n' + branch + '}\n';
};

Blockly.CSharp['controls_flow_statements'] = function(block) {
  return block.getFieldValue('FLOW').toLowerCase() + ';\n';
};

// --- МАТЕМАТИКА ---
Blockly.CSharp['math_number'] = function(block) {
  const code = String(block.getFieldValue('NUM'));
  return [code, code < 0 ? Blockly.CSharp.ORDER_UNARY_PREFIX : Blockly.CSharp.ORDER_ATOMIC];
};

Blockly.CSharp['math_arithmetic'] = function(block) {
  const OPERATORS = {
    'ADD': [' + ', Blockly.CSharp.ORDER_ADDITIVE], 'MINUS': [' - ', Blockly.CSharp.ORDER_ADDITIVE],
    'MULTIPLY': [' * ', Blockly.CSharp.ORDER_MULTIPLICATIVE], 'DIVIDE': [' / ', Blockly.CSharp.ORDER_MULTIPLICATIVE],
    'POWER': [null, Blockly.CSharp.ORDER_NONE]
  };
  const tuple = OPERATORS[block.getFieldValue('OP')];
  const operator = tuple[0];
  const order = tuple[1];
  const arg0 = Blockly.CSharp.valueToCode(block, 'A', order) || '0';
  const arg1 = Blockly.CSharp.valueToCode(block, 'B', order) || '0';
  if (!operator) {
    const code = `Math.Pow(${arg0}, ${arg1})`;
    return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
  }
  return [`${arg0}${operator}${arg1}`, order];
};

Blockly.CSharp['math_single'] = function(block) {
  const op = block.getFieldValue('OP');
  const arg = Blockly.CSharp.valueToCode(block, 'NUM', Blockly.CSharp.ORDER_UNARY_PREFIX) || '0';
  let code;
  let order;
  switch(op) {
      case 'ROOT': code = `Math.Sqrt(${arg})`; order = Blockly.CSharp.ORDER_FUNCTION_CALL; break;
      case 'ABS': code = `Math.Abs(${arg})`; order = Blockly.CSharp.ORDER_FUNCTION_CALL; break;
      case 'NEG': code = `-${arg}`; order = Blockly.CSharp.ORDER_UNARY_PREFIX; break;
      case 'LN': code = `Math.Log(${arg})`; order = Blockly.CSharp.ORDER_FUNCTION_CALL; break;
      case 'LOG10': code = `Math.Log10(${arg})`; order = Blockly.CSharp.ORDER_FUNCTION_CALL; break;
      case 'EXP': code = `Math.Exp(${arg})`; order = Blockly.CSharp.ORDER_FUNCTION_CALL; break;
      case 'POW10': code = `Math.Pow(10, ${arg})`; order = Blockly.CSharp.ORDER_FUNCTION_CALL; break;
      default: throw new Error('Unknown math single operator: ' + op);
  }
  return [code, order];
};

Blockly.CSharp['math_trig'] = function(block) {
  const op = block.getFieldValue('OP');
  const arg = Blockly.CSharp.valueToCode(block, 'NUM', Blockly.CSharp.ORDER_NONE) || '0';
  const argInRad = `(double)${arg} * (Math.PI / 180.0)`;
  let code;
  switch(op) {
      case 'SIN': code = `Math.Sin(${argInRad})`; break;
      case 'COS': code = `Math.Cos(${argInRad})`; break;
      case 'TAN': code = `Math.Tan(${argInRad})`; break;
      case 'ASIN': code = `Math.Asin((double)${arg}) / (Math.PI / 180.0)`; break;
      case 'ACOS': code = `Math.Acos((double)${arg}) / (Math.PI / 180.0)`; break;
      case 'ATAN': code = `Math.Atan((double)${arg}) / (Math.PI / 180.0)`; break;
      default: throw new Error('Unknown math trig operator: ' + op);
  }
  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['math_constant'] = function(block) {
  const CONSTANTS = { 'PI': 'Math.PI', 'E': 'Math.E', 'GOLDEN_RATIO': '(1.0 + Math.Sqrt(5.0)) / 2.0', 'SQRT2': 'Math.Sqrt(2.0)', 'SQRT1_2': 'Math.Sqrt(0.5)', 'INFINITY': 'double.PositiveInfinity' };
  return [CONSTANTS[block.getFieldValue('CONSTANT')], Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['math_round'] = function(block) {
  const op = block.getFieldValue('OP');
  const arg = Blockly.CSharp.valueToCode(block, 'NUM', Blockly.CSharp.ORDER_NONE) || '0';
  const funcs = { 'ROUND': 'Math.Round', 'ROUNDUP': 'Math.Ceiling', 'ROUNDDOWN': 'Math.Floor' };
  const code = `${funcs[op]}(${arg})`;
  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['math_modulo'] = function(block) {
  const arg0 = Blockly.CSharp.valueToCode(block, 'DIVIDEND', Blockly.CSharp.ORDER_MULTIPLICATIVE) || '0';
  const arg1 = Blockly.CSharp.valueToCode(block, 'DIVISOR', Blockly.CSharp.ORDER_MULTIPLICATIVE) || '0';
  const code = `${arg0} % ${arg1}`;
  return [code, Blockly.CSharp.ORDER_MULTIPLICATIVE];
};

Blockly.CSharp['math_change'] = function(block) {
  const variable = block.workspace.getVariableById(block.getFieldValue('VAR'));
  const varName = Blockly.CSharp.getVariableName(variable.getId());
  const delta = Blockly.CSharp.valueToCode(block, 'DELTA', Blockly.CSharp.ORDER_ADDITIVE) || '0';
  return `${varName} += ${delta};\n`;
};

// --- ПЕРЕМЕННЫЕ ---
Blockly.CSharp['variables_get'] = function(block) {
  // Получаем имя переменной, а не ее ID.
  const code = Blockly.CSharp.variableDB_.getName(block.getFieldValue('VAR'), Blockly.Variables.NAME_TYPE);
  return [code, Blockly.CSharp.ORDER_ATOMIC];
};


Blockly.CSharp['variables_set'] = function(block) {
  // Получаем код для значения, которое мы присваиваем.
  const argument0 = Blockly.CSharp.valueToCode(block, 'VALUE', Blockly.CSharp.ORDER_ASSIGNMENT) || 'null';
  // Получаем имя переменной, а не ее ID.
  const varName = Blockly.CSharp.variableDB_.getName(block.getFieldValue('VAR'), Blockly.Variables.NAME_TYPE);
  return `${varName} = ${argument0};\n`;
};

// --- ТЕКСТ ---
Blockly.CSharp['text'] = function(block) {
  const textValue = Blockly.CSharp.quote_(block.getFieldValue('TEXT'));
  return [textValue, Blockly.CSharp.ORDER_ATOMIC];
};

Blockly.CSharp['text_join'] = function(block) {
  if (block.itemCount_ === 0) return ['""', Blockly.CSharp.ORDER_ATOMIC];
  const elements = Array.from({length: block.itemCount_}, (_, i) => `(${Blockly.CSharp.valueToCode(block, 'ADD' + i, Blockly.CSharp.ORDER_NONE) || '""'}).ToString()`);
  return [`string.Concat(${elements.join(', ')})`, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['text_append'] = function(block) {
  const variable = block.workspace.getVariableById(block.getFieldValue('VAR'));
  const varName = Blockly.CSharp.getVariableName(variable.getId());
  const text = Blockly.CSharp.valueToCode(block, 'TEXT', Blockly.CSharp.ORDER_ASSIGNMENT) || '""';
  return `${varName} += ${text};\n`;
};

Blockly.CSharp['text_length'] = function(block) {
  const text = Blockly.CSharp.valueToCode(block, 'VALUE', Blockly.CSharp.ORDER_MEMBER) || '""';
  return [`${text}.Length`, Blockly.CSharp.ORDER_MEMBER];
};

// --- СПИСКИ (предполагаем List<object> для универсальности) ---
Blockly.CSharp['lists_create_with'] = function(block) {
  const elements = Array.from(
    {length: block.itemCount_},
    (_, i) => Blockly.CSharp.valueToCode(block, 'ADD' + i, Blockly.CSharp.ORDER_NONE) || 'null'
  );
  const code = `new List<object> { ${elements.join(', ')} }`;
  return [code, Blockly.CSharp.ORDER_ATOMIC];
};

Blockly.CSharp['lists_repeat'] = function(block) {
  const item = Blockly.CSharp.valueToCode(block, 'ITEM', Blockly.CSharp.ORDER_NONE) || 'null';
  const count = Blockly.CSharp.valueToCode(block, 'NUM', Blockly.CSharp.ORDER_NONE) || '0';
  const code = `new List<object>(Enumerable.Repeat(${item}, (int)${count}))`;
  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['lists_length'] = function(block) {
  const list = Blockly.CSharp.valueToCode(block, 'VALUE', Blockly.CSharp.ORDER_MEMBER) || 'new List<object>()';
  return [`${list}.Count`, Blockly.CSharp.ORDER_MEMBER];
};

Blockly.CSharp['lists_isEmpty'] = function(block) {
  const list = Blockly.CSharp.valueToCode(block, 'VALUE', Blockly.CSharp.ORDER_MEMBER) || 'new List<object>()';
  return [`(${list}.Count == 0)`, Blockly.CSharp.ORDER_EQUALITY];
};

Blockly.CSharp['lists_getIndex'] = function(block) {
    const list = Blockly.CSharp.valueToCode(block, 'VALUE', Blockly.CSharp.ORDER_MEMBER) || 'new List<object>()';
    const where = block.getFieldValue('WHERE') || 'FROM_START';
    const at = Blockly.CSharp.valueToCode(block, 'AT', Blockly.CSharp.ORDER_NONE) || '1';
    const mode = block.getFieldValue('MODE') || 'GET';

    let atCode;
    if (where === 'FIRST') atCode = '0';
    else if (where === 'LAST') atCode = `${list}.Count - 1`;
    else if (where === 'FROM_START') atCode = `(int)(${at}) - 1`;
    else if (where === 'FROM_END') atCode = `${list}.Count - (int)(${at})`;
    else if (where === 'RANDOM') {
        const func = Blockly.CSharp.provideFunction_('GetRandomItem', [
            `object ${Blockly.CSharp.FUNCTION_NAME_PLACEHOLDER_}(List<object> list, Random rand) {`,
            '  if (list.Count == 0) return null;',
            '  int index = rand.Next(list.Count);',
            '  return list[index];',
            '}',
        ]);
        Blockly.CSharp.definitions_['random_instance'] = 'Random rand = new Random();';
        return [`${func}(${list}, rand)`, Blockly.CSharp.ORDER_FUNCTION_CALL];
    } else {
        atCode = `(int)(${at}) - 1`;
    }

    if (mode === 'GET') {
        return [`${list}[${atCode}]`, Blockly.CSharp.ORDER_MEMBER];
    } else if (mode === 'GET_REMOVE') {
        return [`${list}.splice(${atCode}, 1)[0]`, Blockly.CSharp.ORDER_MEMBER]; // C# doesn't have a direct equivalent, this is tricky. Let's simplify.
    } else if (mode === 'REMOVE') {
        return `${list}.RemoveAt(${atCode});\n`;
    }
    return '';
};

Blockly.CSharp['lists_setIndex'] = function(block) {
    const list = Blockly.CSharp.valueToCode(block, 'LIST', Blockly.CSharp.ORDER_MEMBER) || 'new List<object>()';
    const where = block.getFieldValue('WHERE') || 'FROM_START';
    const at = Blockly.CSharp.valueToCode(block, 'AT', Blockly.CSharp.ORDER_NONE) || '1';
    const value = Blockly.CSharp.valueToCode(block, 'TO', Blockly.CSharp.ORDER_ASSIGNMENT) || 'null';
    const mode = block.getFieldValue('MODE') || 'SET';

    let atCode;
    if (where === 'FIRST') atCode = '0';
    else if (where === 'LAST') atCode = `${list}.Count - 1`;
    else if (where === 'FROM_START') atCode = `(int)(${at}) - 1`;
    else if (where === 'FROM_END') atCode = `${list}.Count - (int)(${at})`;
    else { // RANDOM
        Blockly.CSharp.definitions_['random_instance'] = 'Random rand = new Random();';
        atCode = `rand.Next(${list}.Count)`;
    }

    if (mode === 'SET') {
        return `${list}[${atCode}] = ${value};\n`;
    } else { // INSERT
        if (where === 'LAST') return `${list}.Add(${value});\n`;
        return `${list}.Insert(${atCode}, ${value});\n`;
    }
};

// --- ПРОЦЕДУРЫ (ФУНКЦИИ) ---
// Этот раздел полностью заменен на корректную реализацию.
Blockly.CSharp['procedures_defreturn'] = function(block) {
  const funcName = Blockly.CSharp.getProcedureName(block.getFieldValue('NAME'));
  let branch = Blockly.CSharp.statementToCode(block, 'STACK');
  let returnValue = Blockly.CSharp.valueToCode(block, 'RETURN', Blockly.CSharp.ORDER_NONE) || '';
  if (returnValue) {
    returnValue = '  return ' + returnValue + ';\n';
  }

  // Определяем тип возвращаемого значения. Если не указан, ставим 'object'.
  const returnType = block.getReturnType() || 'object';

  const args = [];
  const variables = block.getVars();
  for (let i = 0; i < variables.length; i++) {
    const varModel = block.workspace.getVariableById(variables[i].getId());
    // Определяем тип аргумента. Если не указан, ставим 'object'.
    const varType = varModel.type || 'object'; 
    args.push(varType + ' ' + Blockly.CSharp.getVariableName(variables[i].getId()));
  }

  let code = `${returnType} ${funcName}(${args.join(', ')}) {\n${branch}${returnValue}}`;
  code = Blockly.CSharp.scrub_(block, code);
  // Определения функций добавляются в специальный словарь, чтобы Blockly сам их разместил где нужно.
  Blockly.CSharp.definitions_['%' + funcName] = code;
  return null;
};

Blockly.CSharp['procedures_defnoreturn'] = function(block) {
  const funcName = Blockly.CSharp.getProcedureName(block.getFieldValue('NAME'));
  let branch = Blockly.CSharp.statementToCode(block, 'STACK');
  
  const args = [];
  const variables = block.getVars();
  for (let i = 0; i < variables.length; i++) {
    const varModel = block.workspace.getVariableById(variables[i].getId());
    const varType = varModel.type || 'object';
    args.push(varType + ' ' + Blockly.CSharp.getVariableName(variables[i].getId()));
  }

  let code = `void ${funcName}(${args.join(', ')}) {\n${branch}}`;
  code = Blockly.CSharp.scrub_(block, code);
  Blockly.CSharp.definitions_['%' + funcName] = code;
  return null;
};

Blockly.CSharp['procedures_callreturn'] = function(block) {
  const funcName = Blockly.CSharp.getProcedureName(block.getFieldValue('NAME'));
  const args = [];
  const variables = block.getVars();
  for (let i = 0; i < variables.length; i++) {
    args[i] = Blockly.CSharp.valueToCode(block, 'ARG' + i, Blockly.CSharp.ORDER_NONE) || 'null';
  }
  const code = `${funcName}(${args.join(', ')})`;
  return [code, Blockly.CSharp.ORDER_FUNCTION_CALL];
};

Blockly.CSharp['procedures_callnoreturn'] = function(block) {
  const funcName = Blockly.CSharp.getProcedureName(block.getFieldValue('NAME'));
  const args = [];
  const variables = block.getVars();
  for (let i = 0; i < variables.length; i++) {
    args[i] = Blockly.CSharp.valueToCode(block, 'ARG' + i, Blockly.CSharp.ORDER_NONE) || 'null';
  }
  const code = `${funcName}(${args.join(', ')});\n`;
  return code;
};

Blockly.CSharp['procedures_ifreturn'] = function(block) {
  const condition = Blockly.CSharp.valueToCode(block, 'CONDITION', Blockly.CSharp.ORDER_NONE) || 'false';
  let code = `if (${condition}) {\n`;
  if (block.hasReturnValue_) {
    const value = Blockly.CSharp.valueToCode(block, 'VALUE', Blockly.CSharp.ORDER_NONE) || 'null';
    code += `  return ${value};\n`;
  } else {
    code += '  return;\n';
  }
  code += '}\n';
  return code;
};