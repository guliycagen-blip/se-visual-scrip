// src/theme/se_theme.js

import * as Blockly from 'blockly/core';

export const SeTheme = Blockly.Theme.defineTheme('se_theme', {
    'base': Blockly.Themes.Classic,
    'componentStyles': {
        'workspaceBackgroundColour': '#f0f0f0',
        'toolboxBackgroundColour': '#e0e0e0',
        'toolboxForegroundColour': '#333',
        'flyoutBackgroundColour': '#d0d0d0',
        'flyoutForegroundColour': '#333',
        'scrollbarColour': '#c0c0c0',
        'insertionMarkerColour': '#000000',
        'insertionMarkerOpacity': 0.2,
    },
    'categoryStyles': {
        'logic_category': { 'colour': '#5C81A6' },
        'loop_category': { 'colour': '#5BA55B' },
        'math_category': { 'colour': '#5B67A5' },
        'text_category': { 'colour': '#5BA58C' },
        'list_category': { 'colour': '#745BA5' },
        'colour_category': { 'colour': '#A5745B' },
        'variable_category': { 'colour': '#A55B80' },
        'procedure_category': { 'colour': '#995BA5' }
    },
    'fontStyle': {
        'family': '"Helvetica Neue", Helvetica, Arial, sans-serif',
        'weight': 'normal',
        'size': 12
    }
});