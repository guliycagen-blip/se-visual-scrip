// src/generator/csharp.js

import * as Blockly from 'blockly/core';

Blockly.CSharp = new Blockly.Generator('CSharp');

Blockly.CSharp.addReservedWords(
    'abstract,as,base,bool,break,byte,case,catch,char,checked,class,const,continue,decimal,default,delegate,do,double,else,enum,event,explicit,extern,false,finally,fixed,float,for,foreach,goto,if,implicit,in,int,interface,internal,is,lock,long,namespace,new,null,object,operator,out,override,params,private,protected,public,readonly,ref,return,sbyte,sealed,short,sizeof,stackalloc,static,string,struct,switch,this,throw,true,try,typeof,uint,ulong,unchecked,unsafe,ushort,using,virtual,void,volatile,while'
);

Blockly.CSharp.ORDER_ATOMIC = 0;
Blockly.CSharp.ORDER_MEMBER = 2;
Blockly.CSharp.ORDER_PRIMARY = 1;
Blockly.CSharp.ORDER_UNARY_POSTFIX = 3;
Blockly.CSharp.ORDER_UNARY_PREFIX = 4;
Blockly.CSharp.ORDER_MULTIPLICATIVE = 5;
Blockly.CSharp.ORDER_ADDITIVE = 6;
Blockly.CSharp.ORDER_SHIFT = 7;
Blockly.CSharp.ORDER_RELATIONAL = 8;
Blockly.CSharp.ORDER_EQUALITY = 9;
Blockly.CSharp.ORDER_LOGICAL_AND = 10;
Blockly.CSharp.ORDER_LOGICAL_XOR = 11;
Blockly.CSharp.ORDER_LOGICAL_OR = 12;
Blockly.CSharp.ORDER_CONDITIONAL_AND = 13;
Blockly.CSharp.ORDER_CONDITIONAL_OR = 14;
Blockly.CSharp.ORDER_NULL_COALESCING = 15;
Blockly.CSharp.ORDER_CONDITIONAL = 16;
Blockly.CSharp.ORDER_ASSIGNMENT = 17;
Blockly.CSharp.ORDER_LAMBDA = 18;
Blockly.CSharp.ORDER_NONE = 99;

/**
 * ИСПРАВЛЕННАЯ ФУНКЦИЯ ИНИЦИАЛИЗАЦИИ
 * @param {!Blockly.Workspace} workspace Рабочая область для генерации кода.
 */
Blockly.CSharp.init = function(workspace) {
  // Инициализируем словари для определений и имен функций.
  Blockly.CSharp.definitions_ = Object.create(null);
  Blockly.CSharp.functionNames_ = Object.create(null);

  // КЛЮЧЕВОЕ ИСПРАВЛЕНИЕ: Используем 'Blockly.CSharp' вместо 'this'
  if (!Blockly.CSharp.variableDB_) {
    // Эта ошибка больше не должна возникать, так как конструктор Generator создает variableDB_
    throw new Error('Database of variables not initialized for C# generator.');
  }
  Blockly.CSharp.variableDB_.setVariableMap(workspace.getVariableMap());
  Blockly.CSharp.variableDB_.reset();
};


Blockly.CSharp.finish = function(code) {
  const definitions = [];
  for (const name in Blockly.CSharp.definitions_) {
    definitions.push(Blockly.CSharp.definitions_[name]);
  }
  // Используем 'Blockly.CSharp' вместо 'this'
  if (Blockly.CSharp.variableDB_) {
    Blockly.CSharp.variableDB_.reset();
  }
  return definitions.join('\n\n') + '\n\n\n' + code;
};

Blockly.CSharp.scrubNakedValue = function(line) {
  return line + ';\n';
};

Blockly.CSharp.quote_ = function(string) {
  string = string.replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/"/g, '\\"');
  return '"' + string + '"';
};

Blockly.CSharp.scrub_ = function(block, code, opt_thisOnly) {
  const nextBlock = block.nextConnection && block.nextConnection.targetBlock();
  const nextCode = opt_thisOnly ? '' : Blockly.CSharp.blockToCode(nextBlock);
  return code + nextCode;
};

Blockly.CSharp.getProcedureName = function(name) {
  return Blockly.CSharp.variableDB_.getName(name, Blockly.Procedures.NAME_TYPE);
};

Blockly.CSharp.getVariableName = function(var_id) {
    return Blockly.CSharp.variableDB_.getName(var_id, Blockly.Variables.NAME_TYPE);
}