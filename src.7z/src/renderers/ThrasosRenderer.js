// src/renderers/ThrasosRenderer.js

import * as Blockly from 'blockly/core';
import { Constants as GerasConstants, Drawer as GerasDrawer, RenderInfo as GerasRenderInfo } from './GerasRenderer.js';

const RENDERER_NAME = 'thrasos';

class Renderer extends Blockly.blockRendering.Renderer {
  constructor() { // Имя больше не передается как параметр
    super(RENDERER_NAME);
  }
  makeConstants_() {
    return new Constants();
  }
  makeDrawer_(block, info) {
    return new Drawer(block, info);
  }
  makeRenderInfo_(block) {
    return new RenderInfo(this, block);
  }
}

class Constants extends GerasConstants {
  constructor() {
    super();
    this.CORNER_RADIUS = 4;
  }
}

class Drawer extends GerasDrawer {
  constructor(block, info) {
    super(block, info);
  }
}

class RenderInfo extends GerasRenderInfo {
  constructor(renderer, block) {
    super(renderer, block);
  }
}

// ЭКСПОРТИРУЕМ ГЛАВНЫЙ КЛАСС РЕНДЕРЕРА
export { Renderer as ThrasosRenderer };

// СТРОКА РЕГИСТРАЦИИ УДАЛЕНА!
// Blockly.renderers.register(...) <--- УДАЛЕНО