// src/renderers/GerasRenderer.js

import * as Blockly from 'blockly/core';

// ЭТОТ ФАЙЛ ТЕПЕРЬ ТОЛЬКО ОПРЕДЕЛЯЕТ И ЭКСПОРТИРУЕТ КЛАССЫ.
// ОН БОЛЬШЕ НЕ ВЫПОЛНЯЕТ НИКАКИХ ДЕЙСТВИЙ САМ.

class ConstantProvider extends Blockly.blockRendering.ConstantProvider {
    // ... (содержимое класса без изменений)
    constructor() {
        super();
        this.NO_PADDING = 0;
        this.SMALL_PADDING = 3;
        this.MEDIUM_PADDING = 5;
        this.MEDIUM_LARGE_PADDING = 8;
        this.LARGE_PADDING = 10;
        this.CORNER_RADIUS = 8;
        this.NOTCH_WIDTH = 30;
        this.NOTCH_HEIGHT = 4;
        this.NOTCH_OFFSET_LEFT = 15;
        this.STATEMENT_INPUT_NOTCH_OFFSET = this.NOTCH_OFFSET_LEFT;
        this.STATEMENT_BOTTOM_SPACER = -this.NOTCH_HEIGHT;
        this.STATEMENT_INPUT_SPACER_MIN_WIDTH = 120;
        this.INLINE_INPUT_PADDING = 5;
        this.EXTERNAL_VALUE_INPUT_PADDING = 2;
        this.EMPTY_INLINE_INPUT_PADDING = 14.5;
        this.EMPTY_INLINE_INPUT_HEIGHT = 15;
        this.DUMMY_INPUT_MIN_HEIGHT = this.EMPTY_INLINE_INPUT_HEIGHT;
        this.DUMMY_INPUT_SHADOW_MIN_HEIGHT = this.EMPTY_INLINE_INPUT_HEIGHT;
        this.FIELD_BORDER_RECT_RADIUS = this.CORNER_RADIUS;
        this.FIELD_BORDER_RECT_HEIGHT_WITH_PADDING = this.FIELD_BORDER_RECT_HEIGHT + 2 * this.JAGGED_TEETH.height;
    }
}

class RenderInfo extends Blockly.blockRendering.RenderInfo {
    constructor(renderer, block) {
        super(renderer, block);
    }
}

class Drawer extends Blockly.blockRendering.Drawer {
    constructor(block, info) {
        super(block, info);
    }
}

class Renderer extends Blockly.blockRendering.Renderer {
    constructor() {
        super('geras');
    }
    makeConstants_() {
        return new ConstantProvider();
    }
    makeRenderInfo_(block) {
        return new RenderInfo(this, block);
    }
    makeDrawer_(block, info) {
        return new Drawer(block, info);
    }
}

// ЭКСПОРТИРУЕМ КЛАССЫ, ЧТОБЫ ИХ МОЖНО БЫЛО ИСПОЛЬЗОВАТЬ В ДРУГИХ ФАЙЛАХ
export { ConstantProvider as Constants, RenderInfo, Drawer, Renderer as GerasRenderer };

// СТРОКА РЕГИСТРАЦИИ УДАЛЕНА!
// Blockly.renderers.register(...) <--- УДАЛЕНО